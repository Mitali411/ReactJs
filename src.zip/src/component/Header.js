import React from "react";
import'../header.css'

function Header(){
    return<>
        <h2>KING'S GALARY</h2>
    </>
}
export default Header;

