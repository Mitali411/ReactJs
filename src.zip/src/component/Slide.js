import React from "react";
import Img1 from "../component/images/vk1.jpg";
import Img2 from "../component/images/vk2.jpeg";
import Img3 from "../component/images/vk3.jpg";
import Img4 from "./images/vk4.jpeg";
import Img5 from "./images/vk5.jpg";
import Img7 from "./images/vk7.jpg";
import Img8 from "./images/vk8.jpg";
// import Img9 from "./images/vk9.jpg";
import Img10 from "./images/vk10.jpg";
import'../style.css'


function Slide(){
    return<>
    <div id="carouselExample" className="carousel slide">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src={Img1} className="d-block w-200 text" alt="..."/>
    </div>
    <div className="carousel-item">
      <img src={Img2} className="d-block w-200  text" alt="..."/>
    </div>
    <div className="carousel-item">
      <img src={Img3} className="d-block w-200  text" alt="..."/>
    </div>
    <div className="carousel-item">
      <img src={Img4} className="d-block w-200  text" alt="..."/>
    </div>
    <div className="carousel-item">
      <img src={Img5} className="d-block w-200  text" alt="..."/>
    </div>
    <div className="carousel-item">
      <img src={Img7} className="d-block w-200  text" alt="..."/>
    </div>
    <div className="carousel-item">
      <img src={Img8} className="d-block w-200  text" alt="..."/>
    </div>
    {/* <div className="carousel-item">
      <img src={Img9} className="d-block w-200  text" alt="..."/>
    </div> */}
    <div className="carousel-item">
      <img src={Img10} className="d-block w-200  text" alt="..."/>
    </div>
  </div>
  <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Previous</span>
  </button>
  <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span className="carousel-control-next-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Next</span>
  </button>
</div>
    </>

}

export default Slide;