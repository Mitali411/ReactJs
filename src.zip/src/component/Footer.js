import React from "react";
import'../footer.css'

function Footer(){
    return<h4>Thank you</h4>
}
export default Footer;