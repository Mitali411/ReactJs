export const moblie=[
    {
       id:1,
       Name:"Realme 8 pro",
       description:"Inspired by the radiant and boundless universe, realme 8 Pro's design mimics the night sky filled with a multitude of tiny stars, dreamlike and futuristic. It's like holding infinity in your hand. It also adopted the stylish big LOGO design boldly, making you become the protagonist in the crowd."
    },
    {
        id:2,
        Name:"One Plus",
        description:"OnePlus Technology (Shenzhen) Co., Ltd. (Chinese: 一加科技; pinyin: Yījiā Kējì), doing business as OnePlus, is a Chinese consumer electronics manufacturer headquartered in Shenzhen, Guangdong. It is a subsidiary of Oppo."
     },
     {
        id:3,
        Name:"I phone 13 pro",
        description:"An iPhone is a smartphone made by Apple that combines a computer, iPod, digital camera, and cellular phone with a touchscreen interface123. It was announced in 2007 and uses a multi-touch screen that can be manipulated by two finger touches23. Apple designs and markets the iPhone, but it is manufactured by other companies under contract"
     },
     {
        id:4,
        Name:"sumsung galaxy",
        description:"Samsung Galaxy is a series of computing and mobile computing devices by Samsung Electronics that use the Android operating system or Windows 1012. The series includes smartphones, tablets, phablets, foldable devices, and smartwatches12. The first Samsung Galaxy smartphone was released in 2009 and the first tablet in 20102. The devices have a custom user interface called One UI1."
     },
     {
        id:5,
        Name:"vivo",
        description:"Vivo Communication Technology Co. Ltd. (styled as vivo) is a Chinese multinational technology company headquartered in Dongguan, Guangdong that designs and develops smartphones, smartphone accessories, software and online services. "
     },
     

]