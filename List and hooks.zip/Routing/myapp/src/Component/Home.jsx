import React from 'react'

function Home() {
  return (
    <div>
      <h1>welcome </h1>
    </div>
  )
}

export default Home
