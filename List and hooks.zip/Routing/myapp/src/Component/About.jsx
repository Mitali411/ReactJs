import React from 'react'

function About() {
  return (
    <div>
      <h1>Hello Products</h1>
    </div>
  )
}

export default About
