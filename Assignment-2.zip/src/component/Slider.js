import React ,{useState} from "react";
import bg1 from "./images/bg1.jpg";
import bg2 from "./images/bg2.jpg";
import bg3 from "./images/bg3.jpg";
import bg4 from "./images/bg4.jpg";
import './css/slide.css'
export default function Slider() {

   
    const[selectImage, setSelectImage]=useState(0)
    const[allImages, setAllImages]=useState([bg4,bg1,bg2,bg3]);

    return<>
   
    
      
    
         <div className="design">
            <img src={allImages[selectImage]} className="design2" alt=" "></img>
           </div>
           <div className="design3">
            <div>
       <button  onClick={() =>{
            if(selectImage >0)
            setSelectImage(selectImage-1)
           }}><p className="prev">&lt;</p></button>
           </div>
           <div>
            <button onClick={() =>{
            if(selectImage<allImages.length-1)
            setSelectImage(selectImage+1)
           }}><p  className="next">&gt;</p></button>
           </div>
           </div> 
           </>
    
    
}