import React from 'react'

function AddProduct() {
  return (
    <div>
      <br/>
      <h1 style={{textAlign: 'center', color:"gray"}}>Welcome To Our Website..</h1>
      <br/>
      
      <div id="carouselExampleIndicators" className="carousel slide" data-bs-ride="carousel">
  <div className="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to={0} className="active" aria-current="true" aria-label="Slide 1" />
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to={1} aria-label="Slide 2" />
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to={2} aria-label="Slide 3" />
  </div>
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src="https://wallpaperboat.com/wp-content/uploads/2020/08/29/53968/road-04-640x1138.jpg" className="d-block w-100" alt="..." style={{width:"500px" ,height:"700px"}} />
    </div>
    <div className="carousel-item">
      <img src='https://th.bing.com/th/id/R.f505a73312065cef2fd6022235498df5?rik=i61WeNNGuCNixw&riu=http%3a%2f%2fimages.unsplash.com%2fphoto-1524001049154-d5aae8dc7fbd%3fixlib%3drb-1.2.1%26q%3d80%26fm%3djpg%26crop%3dentropy%26cs%3dtinysrgb%26w%3d1080%26fit%3dmax%26ixid%3deyJhcHBfaWQiOjEyMDd9&ehk=YpyIO2NGz9zJEBY7JGXoFOBNIO6U37I48WLRwTUFxwY%3d&risl=&pid=ImgRaw&r=0' className="d-block w-100" alt="..." style={{width:"500px" ,height:"700px"}} />
    </div>
    <div className="carousel-item">
      <img src="https://images.unsplash.com/photo-1549415714-23c875946516?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1000&q=80" className="d-block w-100" alt="..." style={{width:"500px" ,height:"700px"}} />
    </div>
  </div>
  <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span className="carousel-control-prev-icon" aria-hidden="true" />
    <span className="visually-hidden">Previous</span>
  </button>
  <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span className="carousel-control-next-icon" aria-hidden="true" />
    <span className="visually-hidden">Next</span>
  </button>
</div>

    </div>
  )
}

export default AddProduct
