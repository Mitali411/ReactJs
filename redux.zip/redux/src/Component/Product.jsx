import React, { useContext, useEffect } from 'react'
import { useDispatch,useSelector} from 'react-redux'
import { getProduct,addTocart } from '../Redux/ProductSlice';
// import { wrapeercontext } from '../App';


function Product() {
    const dispatch=useDispatch();
    // const{}=useContext(wrapeercontext)
    const{product, loading}=useSelector((state)=>state.product)

    useEffect(()=>{
      // const searchproduct=product.filter((item)=>{
      //   return (
      //     item.title.toLowerCase().includes(search)
      //   )
      // })
      
       dispatch(getProduct());
      //  dispatch(searchProduct())
    }, [ ])

    if(loading) {
      return(
        <h4>Loading...</h4>
      )
     
    }
  return (

    <div>
         <div className="container moveUpAnimation">
      <h1>Products List</h1>
      <div className="row">
        
        {
          
          product.map((item)=>{
            const{description, price, title, image, id , isAdded}=item;
            return (
                <div className="col-md-4 mb-4" key={id}>
                <div className="card">
                   <img
                  src={image}
                  style={{
                    width: 200,
                    height: 200,
                    objectFit: "cover",
                    display: "block",
                    margin: "0 auto",
                  }}
                  alt={title}
                />

                    </div>
                    <div className="card-body">
                    <h6 className="text-truncate">{title}</h6>
                  <p>{price}</p>
                  <p className="text-truncate">{description}</p>
                  {
                    isAdded?( <button className="btn btn-danger" >Go to cart</button>):(<button className="btn btn-primary" onClick={()=>dispatch(addTocart(item))}>Add To Cart</button>)
                  }
                  
                    </div>
                </div>
            
            )
          })
        }
      </div>
      </div>
    </div>
  )
}

export default Product
