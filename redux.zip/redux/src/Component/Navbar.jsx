import React, { useContext } from 'react'
import { NavLink } from 'react-router-dom'
import {AiOutlineShoppingCart} from "react-icons/ai";
import { useSelector } from 'react-redux';
import { wrapeercontext } from '../App';

function Navbar() {
  const {search, setSearch}=useContext(wrapeercontext)

  const {carts}=useSelector((state)=>state.product)
  
  return (
    <div>
  <nav className="navbar navbar-expand-lg navbar-light bg-light">
    <div className="container-fluid">
      <a className="navbar-brand" href="#">Navbar</a>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon" />
      </button>
      <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
          <li className="nav-item">
            <NavLink className="nav-link active" aria-current="page" to="/home">Home</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/counter">Counter</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/product">Product</NavLink>
          </li>
          {/* <li className="nav-item">
            <NavLink className="nav-link" to="/Add-product">Add Product</NavLink>
          </li> */}
          {/* <li className="nav-item">
            <NavLink className="nav-link" to="/view-product">view product</NavLink>
          </li> */}
         
          
        </ul>
        <NavLink className="nav-link position-relative" to="/cart">
              <AiOutlineShoppingCart />
              <span
                className="position-absolute top-0 start-100 translate-middle bg-danger border border-light rounded-circle"
                style={{
                  width: "20px",
                  height: "20px",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  fontWeight: 800,
                  color: "white",
                  fontSize: "10px",
                }}
              >
                <span>{carts.length}</span>
              </span>
            </NavLink>
            <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" value={search} onChange={(e)=>setSearch(e.target.value)} placeholder="Search" aria-label="Search"/>
        <button class="btn btn-outline-success" type="submit">Search</button>
        
      </form>
      </div>
    </div>
  </nav>
</div>

  )
}

export default Navbar
