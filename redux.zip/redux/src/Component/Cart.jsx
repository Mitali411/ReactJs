import React from 'react'

function Cart() {
  return (
    <div>
        <h1>Add Cart</h1>
      
    </div>
  )
}

export default Cart
