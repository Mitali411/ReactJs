import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { increment,decrement,chnageusername } from '../Redux/CounterSlice';
function Counter() {
    const {number,userName}=useSelector((state) => state.counter);
    const dispatch = useDispatch();
  return (
    <div>
      <h1 style={{textAlign:'center'}}>Your Account Balance:{number} </h1>
    <p style={{textAlign:'center' ,fontSize:'20px'}}>Name:{userName}</p>
    <hr></hr>

    <button style={{marginLeft:"700px", fontSize:"20px"}}   onClick={()=>dispatch( increment(66))} className="btn btn-danger">+</button>
    <button style={{marginLeft:"10px",fontSize:"20px"}} onClick={()=>dispatch( decrement())} className="btn btn-primary">-</button>
    <div>
    <button onClick={()=>dispatch(chnageusername("Movika"))} style={{marginLeft:"670px",fontSize:"20px",marginTop:"20px"}} >Change Name</button>
    </div>
    
    
    </div>
  )
}

export default Counter
