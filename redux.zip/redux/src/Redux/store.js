import { configureStore } from "@reduxjs/toolkit";
import CounterSlice from "./CounterSlice";
import ProductSlice from "./ProductSlice";
// import ApiProductSlice from "./ApiProductSlice";


 export const store=configureStore({
    reducer:{
         counter:CounterSlice,
         product:ProductSlice,
     //     apiproduct:ApiProductSlice
    }
    
})