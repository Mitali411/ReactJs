import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import axios from "axios"

export const getProduct=createAsyncThunk('api/getproducts', async() =>{
    try{
        const response = await axios.get("https://fakestoreapi.com/products")
        return response.data;
    }catch(e){
        console.log('error',e);
    }
})

const productSlice=createSlice({
    name:"product",
    initialState:{
        product:[],
        loading:true,
        carts:[],
        serach:[""]
    },
    reducers:{
        addTocart:(state,action)=>{
            const cartId=action.payload.id;

            const addedProduct=state.product.map((item)=>{
                if(item.id===cartId){
                    return{...item ,isAdded: true}
                }
                else{
                    return item
                }
            })
            state.product=addedProduct;
            state.carts=[...state.carts, action.payload]
            
        }


    },
    extraReducers:{
       [getProduct.pending]:(state,action)=>{
        state.loading=true

       },
       [getProduct.fulfilled]:(state,action)=>{

        const modifydata=action.payload.map((item)=>{
            return{...item,isAdded: false}
        })
        state.loading=false
        state.product=modifydata

        const searchproduct=action.payload.filter((item)=>{
            return (
                item.title.toLowerCase().includes(state.serach)
              )
                
        })
        state.serach=action.payload
        state.product=searchproduct

        


       },
       [getProduct.rejected]:(state,action)=>{
        state.loading=false

       }
    }

})
export const{addTocart}=productSlice.actions;
export default productSlice.reducer