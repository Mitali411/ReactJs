import { createSlice } from "@reduxjs/toolkit";


const numberslice= createSlice({ 
    name:"counter",
    initialState:{
        number:0,
        userName:"Mitali"
    },
    reducers:{
        increment: (state,action)=>{
            state.number=state.number+action.payload
        },
        decrement: (state,action)=>{
            state.number=state.number-1
        },
        chnageusername :(state,action)=>{
            state.userName=action.payload
        }

    }
})
export const{increment,decrement,chnageusername}=numberslice.actions;
export default numberslice.reducer