

import { Routes,Route } from 'react-router-dom';
import Navbar from './Component/Navbar';
import Counter from './Component/Counter';
import Product from './Component/Product';
import Cart from './Component/Cart';
import { createContext, useContext, useState } from 'react';
// import ViewProduct from './Component/ViewProduct';
import AddProduct from './Component/AddProduct';
export const wrapeercontext=createContext()

function App() {
  const[search, setSearch]=useState("")

 
  return (
    <>
    <wrapeercontext.Provider value={{search, setSearch}}>
    <Navbar/>
    <Routes>
      <Route path="/counter" element={<Counter/>}></Route>
      <Route path="/product" element={<Product/>}></Route>
      <Route path="/home" element={<AddProduct/>}></Route>
      {/* <Route path="/view-product" element={<ViewProduct/>}></Route> */}
      <Route path="/cart" element={<Cart/>}></Route>
    </Routes>
    </wrapeercontext.Provider>
    </>
    
  );
}

export default App;
